PDF for Printing

This PDF was created in a 4-up mode for professional print purposes.
The paper should be printed on both sides in landscape mode using 
letter-sized paper (8.5 x 11 inches).  Please be aware that the 
back should appear to be upside-down during the printing process.  
Cuts are to be made in the center of the paper, at 5.5 inches on 
the horizontal and 4.25 inches on the vertical side.

The Language Survival Guide can then be stacked and bound along 
the top horizontal edge.  The binding should not exceed 0.5 inches 
so as not to obscure content in the interior folds.  In order to 
increase durability, it is recommended to use card stock or 
similar heavy paper for the front and back flaps.

