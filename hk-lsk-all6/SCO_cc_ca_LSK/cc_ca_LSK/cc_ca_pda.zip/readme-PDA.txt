Short description on how to view swf files on a  Pocket PC device

 

If you would like to view swf files on a Pocket PC (PDA), you need to install "Macromedia Flash Player 6 for Pocket PC 2003" and "Ant FlashAssist 1.3" on your PDA. Any PDA device manufactured from HP, Compaq, Casio or Toshiba can run �Macromedia Flash Player 6 for Pocket PC 2003�. "Macromedia Flash Player 6 for Pocket PC 2003" also supports color devices running Microsoft Pocket PC operating system.

"Macromedia Flash Player 6 for Pocket PC 2003" is a Flash Plug-In operating on a PDA device and can be downloaded for free of charge from http://www.macromedia.com/software/flashplayer/pocketpc/2002.html.  "FlashAssist 1.3" is a software tool for viewing the Macromedia content on the Pocket PC platform. It can be downloaded from http://www.antmobile.com and the price is $14.95.
