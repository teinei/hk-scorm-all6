MP3 Audio Files

The MP3 audio files are named and organized in the same manner
on the CD, however, are compressed at a higher ratio for web
download. The Language Survival Guide audio files can be copy
to CD or other digital media and played on any device that 
supports MP3 playback.
